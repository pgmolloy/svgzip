namespace Svg
{
    public enum SvgVisibility
    {
        Visible,
        Hidden,
        Inherit
    }
}

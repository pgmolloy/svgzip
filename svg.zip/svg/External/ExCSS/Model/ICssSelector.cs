﻿namespace Svg.ExCSS.Model
{
    interface ISupportsSelector
    {
        BaseSelector Selector { get; set; }
    }
}
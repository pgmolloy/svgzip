﻿namespace Svg.ExCSS.Model
{
    interface ISupportsDeclarations
    {
        StyleDeclaration Declarations { get; }
    }
}
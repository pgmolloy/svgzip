﻿
// ReSharper disable once CheckNamespace
namespace Svg.ExCSS
{
    public abstract class Term
    {
        public static readonly InheritTerm Inherit = new InheritTerm();
    }
}

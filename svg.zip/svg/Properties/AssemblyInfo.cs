﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Svg")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("Svg")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2006")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("4b6e2fba-c110-43e9-bd41-e0b7fd067f29")]

[assembly: CLSCompliant(true)]

[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("Svg.UnitTests,PublicKey=" +
    "00240000048000009400000006020000002400005253413100040000010001008d4e723a8c76be" +
"e667607d1fca2c0f0cdcc1c1b926ae46669128282ecad43e6d0776497cd8289dca11e4479773d5" +
"45fc4c557686de548aadbb8652fa550e21d4c402885fec4c1deebfa79e861adb966fc8f4e78235" +
"79a535280ddd3a0168cb4d19522c7591b6693377058675da70e50c7bd6fdceae055cef085f02a0" +
"5a7f0cb4")]